import PySimpleGUI as sg
import numpy as np
from random import choice

"""
    Another simple table created from Input Text Elements.  This demo adds the ability to "navigate" around the drawing using
    the arrow keys. The tab key works automatically, but the arrow keys are done in the code below.
"""

MAX_COLS = 7
MAX_ROWS = 16
sg.change_look_and_feel(choice(sg.list_of_look_and_feel_values()))     # No excuse for gray windows

# Create an Excel style window layout quickly and easily using list comprehensions
# This is an UNUSUAL layout. Normally you do not create layouts by "adding"
wk=('M','T','W','T','F','S','S')
hours =np.linspace(8,19,12,dtype=int)
print(hours)
layout =  [[sg.Text(' '*11)]+[sg.Text(s+ ' '*23) for s in wk] ] + \
          [[sg.T(r)] + [sg.Button(key=(r,c)) for c in range(MAX_COLS)] for r in hours] + \
          [[sg.Button('New')]] + \
          [[sg.Button('Exit')]]
          

# Create the window and show it
window = sg.Window('A Table Simulation', layout, default_element_size=(12,1), element_padding=(1,1), return_keyboard_events=True)
current_cell = (0,0)
while True:             # Event Loop
    event, values = window.read()
    if event in (None, 'Exit'):         # If user closed the window
        break
    current_cell = window.find_element_with_focus().Key
    r,c = current_cell
    # Process arrow keys
    if event.startswith('Down'):
        r = r + 1 * (r < MAX_ROWS-1)
    if event.startswith('Left'):
        c = c - 1 *(c > 0)
    if event.startswith('Right'):
        c = c + 1 *(c < MAX_COLS-1)
    if event.startswith('Up'):
        r = r - 1 * (r > 0)
    # if the current cell changed, set focus on new cell
    if current_cell != (r,c):
      current_cell = r,c
      window[current_cell].set_focus()              # set the focus on the element moved to
      window[current_cell].update(select=True)      # when setting focus, also highlight the data in the element so typing overwrites
